"""
Ayas OS Update Manager - PikaOS Pikman Exact Color Palette & Design System
"""

DARK_THEME_QSS = """
QMainWindow {
    background-color: #1e1e24; /* GTK4 base */
    color: #f0f0f5;
}

QWidget#CentralWidget {
    background-color: #1e1e24;
}

/* Sidebar Styling */
QFrame#SidebarFrame {
    background-color: #26262e;
    border-right: 1px solid #32323e;
    border-top-left-radius: 14px;
    border-bottom-left-radius: 14px;
}

QListWidget#SidebarList {
    background-color: transparent;
    border: none;
    outline: none;
}

QListWidget#SidebarList::item {
    background-color: transparent;
    color: #a0a0b0;
    font-size: 13px;
    font-weight: 600;
    border-radius: 12px;
    padding: 10px 14px;
    margin-bottom: 4px;
}

QListWidget#SidebarList::item:hover {
    background-color: #32323e;
    color: #ffffff;
}

QListWidget#SidebarList::item:selected {
    background-color: #40404e;
    color: #ffffff;
    border: 1px solid #525262;
}

/* Header & Top Bar */
QLineEdit#SearchBar {
    background-color: #2a2a32;
    color: #f0f0f5;
    border: 1px solid #3b3b48;
    border-radius: 18px;
    padding: 8px 16px;
    font-size: 13px;
}

QLineEdit#SearchBar:focus {
    border: 1px solid #d9822b;
}

/* Main Dashboard Cards */
QLabel#DashboardTitle {
    font-size: 26px;
    font-weight: bold;
    color: #ffffff;
}

QFrame#StatPill {
    background-color: #2a2a32;
    border: 1px solid #3b3b48;
    border-radius: 16px; /* Pikman style pill */
    padding: 6px 14px;
}

QLabel#StatLabel {
    color: #a0a0b0;
    font-size: 14px;
    font-weight: bold;
}

QLabel#StatValue {
    background-color: #d9822b; /* Accent background */
    color: #ffffff;
    font-weight: bold;
    border-radius: 12px;
    padding: 2px 10px;
    font-size: 13px;
}

/* Action Buttons */
QPushButton#CommitButton {
    background-color: #d9822b;
    color: #ffffff;
    font-size: 14px;
    font-weight: bold;
    border: none;
    border-radius: 12px;
    padding: 12px 24px;
}

QPushButton#CommitButton:hover {
    background-color: #eb9138;
}

QPushButton#SecondaryButton {
    background-color: #32323e;
    color: #e0e0f0;
    font-size: 13px;
    font-weight: 600;
    border: 1px solid #4a4a58;
    border-radius: 10px;
    padding: 10px 18px;
}

QPushButton#SecondaryButton:hover {
    background-color: #40404e;
    color: #ffffff;
}

/* Package Card Base */
QFrame#PackageCard {
    background-color: #26262e;
    border: 1px solid #32323e;
    border-radius: 14px;
    padding: 12px;
    margin-bottom: 10px;
}

QLabel#PkgName {
    font-size: 16px;
    font-weight: bold;
    color: #ffffff;
}

QLabel#VersionBadge {
    background-color: #32323e;
    color: #a0a0b0;
    border-radius: 8px;
    padding: 4px 10px;
    font-size: 12px;
}

QLabel#FlatpakBadge {
    background-color: #1b4570;
    color: #63a6eb;
    border-radius: 8px;
    padding: 4px 10px;
    font-size: 12px;
    font-weight: bold;
}

/* Tabs Inside Package Details */
QTabWidget#PkgDetailTabs::pane {
    border: 1px solid #32323e;
    border-radius: 10px;
    background-color: #1e1e24;
}

QTabBar::tab {
    background-color: #2a2a32;
    color: #a0a0b0;
    padding: 8px 16px;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    margin-right: 4px;
    font-size: 12px;
}

QTabBar::tab:selected {
    background-color: #40404e;
    color: #ffffff;
    font-weight: bold;
}

/* Progress Bar */
QProgressBar {
    background-color: #26262e;
    border: 1px solid #3b3b48;
    border-radius: 10px;
    text-align: center;
    color: #ffffff;
    font-weight: bold;
}

QProgressBar::chunk {
    background-color: #d9822b;
    border-radius: 9px;
}

/* Log View */
QTextEdit#LogView {
    background-color: #15151a;
    color: #58a6ff;
    font-family: 'Hack', 'Monospace';
    font-size: 13px;
    border: 1px solid #32323e;
    border-radius: 12px;
    padding: 12px;
}
"""
