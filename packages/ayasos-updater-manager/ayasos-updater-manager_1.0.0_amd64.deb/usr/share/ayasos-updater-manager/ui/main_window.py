"""
Ayas OS Update Manager - Full Feature Set with Flatpak, GTK4 styling & About Modal
"""

import sys
import subprocess
import urllib.request
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QPushButton, QListWidget, QListWidgetItem, QProgressBar, 
    QTextEdit, QStackedWidget, QFrame, QCheckBox, QLineEdit,
    QTabWidget, QMessageBox, QScrollArea, QDialog, QTableWidget,
    QTableWidgetItem, QHeaderView, QSpinBox, QComboBox, QFormLayout,
    QSystemTrayIcon, QMenu
)
from PyQt6.QtCore import Qt, QSize, QTimer, QUrl
from PyQt6.QtGui import QIcon, QFont, QColor, QAction, QDesktopServices

from ui.styles import DARK_THEME_QSS
from engine import CheckUpdatesThread, PerformUpdateThread, load_settings, save_settings, DEFAULT_SETTINGS


class AboutDialog(QDialog):
    """
    Ayas OS 'Hakkında' (About) Penceresi
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ayas OS Güncelleme Yöneticisi Hakkında")
        self.setFixedSize(400, 320)
        self.setModal(True)
        self.setStyleSheet(DARK_THEME_QSS)

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        logo = QLabel("🚀")
        logo.setStyleSheet("font-size: 48px;")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo)

        name = QLabel("Ayas OS Güncelleme Yöneticisi")
        name.setStyleSheet("font-size: 16px; font-weight: bold; color: #58a6ff;")
        name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(name)

        ver = QLabel("Sürüm: 1.0.0 (Trixie Edition)")
        ver.setStyleSheet("font-size: 12px; color: #a0a0b0;")
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(ver)

        dev = QLabel("Geliştirici: AYAS OS & AYASCELL Ekibi\nLisans: MPL-2.0 / Açık Kaynak")
        dev.setStyleSheet("font-size: 11px; color: #8b949e;")
        dev.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(dev)

        link = QLabel("<a href='https://github.com/AYASCELL/ayasos-repo' style='color: #58a6ff;'>GitHub Proje Deposu</a>")
        link.setOpenExternalLinks(True)
        link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(link)

        layout.addStretch()

        btn_close = QPushButton("Kapat")
        btn_close.setObjectName("SecondaryButton")
        btn_close.clicked.connect(self.accept)
        layout.addWidget(btn_close)


class UpdateSettingsDialog(QDialog):
    """
    Ayas OS 'Güncelleme & Bildirim Ayarları' Modalı
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Otomatik Güncelleme & Bildirim Ayarları")
        self.setFixedSize(480, 360)
        self.setModal(True)
        self.setStyleSheet(DARK_THEME_QSS)

        self.current_settings = load_settings()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        title = QLabel("⚙️ Güncelleme & Bildirim Ayarları")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")
        layout.addWidget(title)

        form = QFormLayout()
        form.setSpacing(12)

        self.cb_auto_check = QCheckBox("Güncellemeleri Otomatik Denetle")
        self.cb_auto_check.setChecked(self.current_settings.get("auto_check", True))
        self.cb_auto_check.setStyleSheet("color: #f0f0f5; font-weight: bold;")

        self.spin_interval = QSpinBox()
        self.spin_interval.setRange(1, 24)
        self.spin_interval.setValue(self.current_settings.get("check_interval_hours", 6))
        self.spin_interval.setStyleSheet("background-color: #25252e; color: #ffffff; border: 1px solid #333340; padding: 4px; border-radius: 4px;")

        self.cb_notifications = QCheckBox("Masaüstü Bildirimlerini Göster")
        self.cb_notifications.setChecked(self.current_settings.get("show_notifications", True))
        self.cb_notifications.setStyleSheet("color: #f0f0f5;")

        self.cb_autostart = QCheckBox("Sistem Açılışında Arka Planda Başlat")
        self.cb_autostart.setChecked(self.current_settings.get("autostart_on_boot", True))
        self.cb_autostart.setStyleSheet("color: #f0f0f5;")

        form.addRow(self.cb_auto_check)
        form.addRow("Otomatik Kontrol Aralığı (Saat):", self.spin_interval)
        form.addRow(self.cb_notifications)
        form.addRow(self.cb_autostart)

        layout.addLayout(form)
        layout.addStretch()

        btn_box = QHBoxLayout()
        btn_default = QPushButton("🔄 Varsayılana Dön")
        btn_default.setObjectName("SecondaryButton")
        btn_default.clicked.connect(self.restore_defaults)

        btn_cancel = QPushButton("İptal")
        btn_cancel.setObjectName("SecondaryButton")
        btn_cancel.clicked.connect(self.reject)

        btn_save = QPushButton("💾 Kaydet")
        btn_save.setObjectName("CommitButton")
        btn_save.clicked.connect(self.save_and_accept)

        btn_box.addWidget(btn_default)
        btn_box.addStretch()
        btn_box.addWidget(btn_cancel)
        btn_box.addWidget(btn_save)

        layout.addLayout(btn_box)

    def restore_defaults(self):
        defaults = DEFAULT_SETTINGS.copy()
        self.cb_auto_check.setChecked(defaults["auto_check"])
        self.spin_interval.setValue(defaults["check_interval_hours"])
        self.cb_notifications.setChecked(defaults["show_notifications"])
        self.cb_autostart.setChecked(defaults["autostart_on_boot"])

    def save_and_accept(self):
        data = {
            "auto_check": self.cb_auto_check.isChecked(),
            "check_interval_hours": self.spin_interval.value(),
            "show_notifications": self.cb_notifications.isChecked(),
            "autostart_on_boot": self.cb_autostart.isChecked()
        }
        if save_settings(data):
            if self.parent() and hasattr(self.parent(), 'update_auto_check_timer'):
                self.parent().update_auto_check_timer()
            QMessageBox.information(self, "Başarılı", "Güncelleme ayarları başarıyla kaydedildi.")
            self.accept()
        else:
            QMessageBox.warning(self, "Hata", "Ayarlar kaydedilirken bir hata oluştu.")


class TransactionReviewDialog(QDialog):
    """
    Ayas OS 'Güncelleme İncelemesi ve Onayı' Modalı
    """
    def __init__(self, stats, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Güncelleme İşlemi: Lütfen Onaylayın")
        self.setFixedSize(440, 500)
        self.setModal(True)
        self.setStyleSheet(DARK_THEME_QSS)

        self.stats = stats
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        title = QLabel("Güncelleme İşlemi: Lütfen Onaylayın")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")

        subtitle = QLabel("Aşağıdaki değişiklikler sisteminize uygulanacaktır:")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("font-size: 12px; color: #a0a0b0;")

        layout.addWidget(title)
        layout.addWidget(subtitle)

        box = QVBoxLayout()
        box.setSpacing(8)

        def make_pill(label_text, val_text):
            frame = QFrame()
            frame.setObjectName("StatPill")
            frame.setFixedWidth(360)
            fl = QHBoxLayout(frame)
            fl.setContentsMargins(14, 6, 14, 6)
            lbl = QLabel(label_text)
            lbl.setObjectName("StatLabel")
            val = QLabel(str(val_text))
            val.setObjectName("StatValue")
            fl.addWidget(lbl)
            fl.addStretch()
            fl.addWidget(val)
            return frame

        box.addWidget(make_pill("Güncellenecek Paketler", self.stats.get('upgrade', 0)), alignment=Qt.AlignmentFlag.AlignCenter)
        box.addWidget(make_pill("Yeni Kurulacak Paketler", self.stats.get('install', 0)), alignment=Qt.AlignmentFlag.AlignCenter)
        box.addWidget(make_pill("Flatpak Uygulamaları", self.stats.get('flatpak', 0)), alignment=Qt.AlignmentFlag.AlignCenter)
        box.addWidget(make_pill("Kaldırılacak Paketler", self.stats.get('uninstall', 0)), alignment=Qt.AlignmentFlag.AlignCenter)
        box.addWidget(make_pill("Toplam İndirme Boyutu", self.stats.get('download_size', "~14.2 MB")), alignment=Qt.AlignmentFlag.AlignCenter)
        box.addWidget(make_pill("Diskte Kaplayacağı Alan", self.stats.get('disk_size', "~48.5 MB")), alignment=Qt.AlignmentFlag.AlignCenter)

        layout.addLayout(box)
        layout.addStretch()

        btn_confirm = QPushButton("Onayla ve Güncelle")
        btn_confirm.setObjectName("CommitButton")
        btn_confirm.clicked.connect(self.accept)

        btn_decline = QPushButton("İptal Et")
        btn_decline.setObjectName("SecondaryButton")
        btn_decline.clicked.connect(self.reject)

        layout.addWidget(btn_confirm)
        layout.addWidget(btn_decline)


class PackageCardWidget(QFrame):
    """
    Genişletilebilir Paket Kartı
    """
    def __init__(self, pkg_data, parent=None):
        super().__init__(parent)
        self.setObjectName("PackageCard")
        self.pkg_data = pkg_data
        self.is_expanded = False

        self.init_ui()

    def init_ui(self):
        from PyQt6.QtWidgets import QSizePolicy
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(12, 10, 12, 10)
        self.main_layout.setSpacing(8)

        header_row = QHBoxLayout()

        left_box = QVBoxLayout()
        left_box.setSpacing(4)

        pkg_name = QLabel(self.pkg_data['name'])
        pkg_name.setObjectName("PkgName")

        badges_layout = QHBoxLayout()
        badges_layout.setSpacing(6)

        old_v = self.pkg_data['old_version']
        new_v = self.pkg_data['new_version']
        
        is_flatpak = self.pkg_data.get('is_flatpak', False)
        
        if is_flatpak:
            ver_text = f"Kurulu: <span style='color: #f85149;'>{old_v}</span> | Güncellenecek: <span style='color: #3fb950;'>{new_v}</span>"
            f_lbl = QLabel("Flatpak")
            f_lbl.setObjectName("FlatpakBadge")
            badges_layout.addWidget(f_lbl)
        else:
            ver_text = f"Kurulu: <span style='color: #f85149;'>{old_v}</span> | Güncellenecek: <span style='color: #3fb950;'>{new_v}</span> | Mimari: amd64"

        ver_label = QLabel(ver_text)
        ver_label.setObjectName("VersionBadge")
        
        badges_layout.addWidget(ver_label)
        badges_layout.addStretch()

        left_box.addWidget(pkg_name)
        left_box.addLayout(badges_layout)

        header_row.addLayout(left_box)
        header_row.addStretch()

        self.checkbox = QCheckBox()
        self.checkbox.setChecked(self.pkg_data.get('selected', True))
        self.checkbox.setStyleSheet("QCheckBox::indicator { width: 20px; height: 20px; }")
        self.checkbox.toggled.connect(self.on_checkbox_toggled)

        self.btn_toggle = QPushButton("▼")
        self.btn_toggle.setFixedSize(30, 30)
        self.btn_toggle.setStyleSheet("background-color: #32323e; color: #ffffff; border-radius: 15px; font-weight: bold; font-size: 12px;")
        self.btn_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_toggle.clicked.connect(self.toggle_expanded)

        header_row.addWidget(self.checkbox, alignment=Qt.AlignmentFlag.AlignVCenter)
        header_row.addSpacing(10)
        header_row.addWidget(self.btn_toggle, alignment=Qt.AlignmentFlag.AlignVCenter)

        self.main_layout.addLayout(header_row)

        self.detail_tabs = QTabWidget()
        self.detail_tabs.setObjectName("PkgDetailTabs")
        self.detail_tabs.setFixedHeight(120)
        self.detail_tabs.setVisible(False)

        # Tab 1: Açıklama
        tab_desc = QWidget()
        l_desc = QVBoxLayout(tab_desc)
        l_desc.setContentsMargins(8, 8, 8, 8)
        t_desc = QTextEdit()
        t_desc.setReadOnly(True)
        t_desc.setText(self.pkg_data.get('summary', 'Açıklama bulunmuyor.'))
        t_desc.setStyleSheet("background: transparent; border: none; color: #c9d1d9;")
        l_desc.addWidget(t_desc)
        self.detail_tabs.addTab(tab_desc, "Açıklama")

        # Tab 2: Ek Bilgi
        tab_info = QWidget()
        l_info = QVBoxLayout(tab_info)
        l_info.setContentsMargins(8, 8, 8, 8)
        
        maint = self.pkg_data.get('maintainer', 'AYAS OS Ekibi <info@ayasos.org>' if self.pkg_data.get('is_ayasos') else 'Debian / Linux Topluluğu')
        size_str = self.pkg_data.get('size_str', '~1.2 MB')
        site_str = self.pkg_data.get('origin_site', 'https://AYASCELL.github.io/ayasos-repo/' if self.pkg_data.get('is_ayasos') else 'Debian / Sistem Deposu')

        if is_flatpak:
            info_text = f"Uygulama ID: {self.pkg_data.get('flatpak_id', '')}\nGeliştirici: Flathub\nYükleme Türü: System"
        else:
            info_text = f"Geliştirici / Bakımcı: {maint}\nİndirme Boyutu: {size_str}\nKaynak Depo: {site_str}"
        
        t_info = QTextEdit()
        t_info.setReadOnly(True)
        t_info.setText(info_text)
        t_info.setStyleSheet("background: transparent; border: none; color: #d29922;")
        l_info.addWidget(t_info)
        self.detail_tabs.addTab(tab_info, "Ek Bilgi")

        # Tab 3: İndirme Adresi
        tab_uri = QWidget()
        l_uri = QVBoxLayout(tab_uri)
        l_uri.setContentsMargins(8, 8, 8, 8)
        if is_flatpak:
            uri_text = "https://dl.flathub.org/repo/"
        else:
            uri_text = site_str
        t_uri = QTextEdit()
        t_uri.setReadOnly(True)
        t_uri.setText(uri_text)
        t_uri.setStyleSheet("background: transparent; border: none; color: #58a6ff;")
        l_uri.addWidget(t_uri)
        self.detail_tabs.addTab(tab_uri, "İndirme Adresi")

        # Tab 4: Değişiklikler
        tab_change = QWidget()
        l_change = QVBoxLayout(tab_change)
        l_change.setContentsMargins(8, 8, 8, 8)
        t_change = QTextEdit()
        t_change.setReadOnly(True)
        t_change.setText(f"* {self.pkg_data['name']} ({new_v}) güncellemesi mevcut.")
        t_change.setStyleSheet("background: transparent; border: none; color: #3fb950;")
        l_change.addWidget(t_change)
        self.detail_tabs.addTab(tab_change, "Değişiklik Notları")

        self.main_layout.addWidget(self.detail_tabs)

    def on_checkbox_toggled(self, checked):
        self.pkg_data['selected'] = checked

    def toggle_expanded(self):
        self.is_expanded = not self.is_expanded
        self.detail_tabs.setVisible(self.is_expanded)
        self.btn_toggle.setText("▲" if self.is_expanded else "▼")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Ayas OS Güncelleme Yöneticisi")
        self.resize(980, 680)
        self.setMinimumSize(920, 600)

        self.setStyleSheet(DARK_THEME_QSS)

        self.current_packages = []
        self.cards_list = []
        self.all_card_widgets = []

        self.check_thread = None
        self.update_thread = None

        self.init_ui()
        self.init_tray()

        # İnternet kontrol timer'ı
        self.net_timer = QTimer(self)
        self.net_timer.timeout.connect(self.check_internet_connection)
        self.net_timer.start(10000)

        # Periyodik otomatik güncelleme kontrol timer'ı
        self.auto_check_timer = QTimer(self)
        self.auto_check_timer.timeout.connect(self.on_auto_check_timer_timeout)
        self.update_auto_check_timer()

        self.on_check_updates()

    def init_ui(self):
        central_widget = QWidget(self)
        central_widget.setObjectName("CentralWidget")
        self.setCentralWidget(central_widget)

        root_layout = QHBoxLayout(central_widget)
        root_layout.setContentsMargins(10, 10, 10, 10)
        root_layout.setSpacing(10)

        # 1. SOL SIDEBAR MENÜSÜ
        sidebar_frame = QFrame()
        sidebar_frame.setObjectName("SidebarFrame")
        sidebar_frame.setFixedWidth(240)

        sidebar_layout = QVBoxLayout(sidebar_frame)
        sidebar_layout.setContentsMargins(10, 14, 10, 14)
        sidebar_layout.setSpacing(10)

        self.sidebar_list = QListWidget()
        self.sidebar_list.setObjectName("SidebarList")
        self.sidebar_list.setFixedHeight(380)
        self.sidebar_list.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.sidebar_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        menu_items = [
            "Ana Güncelleme Sayfası",
            "Sistem Paketleri (APT)",
            "Ayas OS Paketleri",
            "Flatpak Paketleri",
            "Depo & APT Ayarları",
            "Flatpak Ayarları",
            "Terminal Logları",
            "⚙️ Ayarlar"
        ]

        for item_text in menu_items:
            item = QListWidgetItem(item_text)
            item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.sidebar_list.addItem(item)

        self.current_sidebar_row = 0
        self.sidebar_list.setCurrentRow(0)
        self.sidebar_list.currentRowChanged.connect(self.on_sidebar_changed)

        sidebar_layout.addWidget(self.sidebar_list)
        sidebar_layout.addStretch()

        ver_lbl = QLabel("Ayas OS v13 Trixie")
        ver_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ver_lbl.setStyleSheet("color: #5c5c6e; font-size: 11px;")
        sidebar_layout.addWidget(ver_lbl)

        root_layout.addWidget(sidebar_frame)

        # 2. SAĞ ANA İÇERİK ALANI
        right_container = QWidget()
        right_layout = QVBoxLayout(right_container)
        right_layout.setContentsMargins(4, 4, 4, 4)
        right_layout.setSpacing(10)

        # İNTERNET UYARI BANNERI
        self.net_banner = QLabel("⚠️ İnternet bağlantısı tespit edilemedi. Paket depoları taranamıyor.")
        self.net_banner.setStyleSheet("""
            QLabel {
                background-color: #7a282b;
                color: #ffffff;
                font-weight: bold;
                border-radius: 8px;
                padding: 8px;
            }
        """)
        self.net_banner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.net_banner.setVisible(False)
        right_layout.addWidget(self.net_banner)

        # YENİDEN BAŞLAT UYARI BANNERI
        self.reboot_banner = QFrame()
        self.reboot_banner.setStyleSheet("QFrame { background-color: #1e3a8a; border: 1px solid #2563eb; border-radius: 8px; }")
        rb_layout = QHBoxLayout(self.reboot_banner)
        rb_layout.setContentsMargins(12, 6, 12, 6)
        rb_label = QLabel("⚠️ Sistem güncellemelerinin tamamlanması için bilgisayarınızı yeniden başlatmanız gerekiyor.")
        rb_label.setStyleSheet("color: #ffffff; font-weight: bold; font-size: 12px;")
        btn_reboot_now = QPushButton("⚡ Şimdi Yeniden Başlat")
        btn_reboot_now.setObjectName("CommitButton")
        btn_reboot_now.clicked.connect(self.on_reboot_now)
        rb_layout.addWidget(rb_label)
        rb_layout.addStretch()
        rb_layout.addWidget(btn_reboot_now)
        self.reboot_banner.setVisible(False)
        right_layout.addWidget(self.reboot_banner)

        from PyQt6.QtWidgets import QStyle
        # SAĞ ÜST HEADER (YENİLE & HAKKINDA BUTONLARI)
        top_header = QHBoxLayout()
        top_header.addStretch()

        btn_refresh = QPushButton(" Denetle")
        btn_refresh.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_BrowserReload))
        btn_refresh.setToolTip("Güncellemeleri Denetle")
        btn_refresh.setFixedHeight(36)
        btn_refresh.setObjectName("SecondaryButton")
        btn_refresh.clicked.connect(self.on_check_updates)

        btn_about = QPushButton()
        btn_about.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxInformation))
        btn_about.setToolTip("Hakkında")
        btn_about.setFixedSize(36, 36)
        btn_about.setObjectName("SecondaryButton")
        btn_about.clicked.connect(self.on_show_about)

        top_header.addWidget(btn_refresh)
        top_header.addWidget(btn_about)

        right_layout.addLayout(top_header)

        self.pages_stack = QStackedWidget()

        # PAGE 0: ANA GÜNCELLEME SAYFASI
        page_dash = QWidget()
        dash_layout = QVBoxLayout(page_dash)
        dash_layout.setContentsMargins(20, 10, 20, 20)

        dash_layout.addStretch()

        icon_box = QHBoxLayout()
        icon_box.addStretch()

        self.dash_icon_label = QLabel("📦")
        self.dash_icon_label.setStyleSheet("font-size: 72px;")
        
        self.dash_title = QLabel("Güncellemeler Mevcut!")
        self.dash_title.setObjectName("DashboardTitle")

        icon_box.addWidget(self.dash_icon_label)
        icon_box.addWidget(self.dash_title)
        icon_box.addStretch()
        dash_layout.addLayout(icon_box)

        dash_layout.addSpacing(30)

        stats_box = QVBoxLayout()
        stats_box.setSpacing(8)
        stats_box.setAlignment(Qt.AlignmentFlag.AlignCenter)

        def make_dash_pill(label_text):
            pill = QFrame()
            pill.setObjectName("StatPill")
            pill.setFixedWidth(360)
            pl = QHBoxLayout(pill)
            pl.setContentsMargins(14, 6, 14, 6)
            lbl = QLabel(label_text)
            lbl.setObjectName("StatLabel")
            val = QLabel("0")
            val.setObjectName("StatValue")
            pl.addWidget(lbl)
            pl.addStretch()
            pl.addWidget(val)
            return pill, val

        pill_total, self.val_total = make_dash_pill("Toplam Güncelleme")
        pill_apt, self.val_apt = make_dash_pill("Sistem Güncellemeleri (APT)")
        pill_ayas, self.val_ayas = make_dash_pill("Ayas OS Güncellemeleri")
        pill_fp, self.val_fp = make_dash_pill("Flatpak Uygulamaları")

        stats_box.addWidget(pill_total, alignment=Qt.AlignmentFlag.AlignCenter)
        stats_box.addWidget(pill_apt, alignment=Qt.AlignmentFlag.AlignCenter)
        stats_box.addWidget(pill_ayas, alignment=Qt.AlignmentFlag.AlignCenter)
        stats_box.addWidget(pill_fp, alignment=Qt.AlignmentFlag.AlignCenter)

        dash_layout.addLayout(stats_box)
        dash_layout.addStretch()

        dash_bottom = QHBoxLayout()
        dash_bottom.addStretch()

        self.btn_commit_dash = QPushButton("Tüm Güncellemeleri Uygula")
        self.btn_commit_dash.setObjectName("CommitButton")
        self.btn_commit_dash.clicked.connect(self.prompt_transaction_review)
        dash_bottom.addWidget(self.btn_commit_dash)

        dash_layout.addLayout(dash_bottom)
        self.pages_stack.addWidget(page_dash)

        # PAGE 1: SİSTEM PAKETLERİ (LIST VIEW)
        page_native = QWidget()
        native_layout = QVBoxLayout(page_native)
        native_layout.setContentsMargins(8, 8, 8, 8)

        self.search_bar = QLineEdit()
        self.search_bar.setObjectName("SearchBar")
        self.search_bar.setPlaceholderText("🔍 Paket veya uygulama ara...")
        self.search_bar.textChanged.connect(self.on_search_text_changed)
        native_layout.addWidget(self.search_bar)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        self.scroll_content = QWidget()
        self.cards_vbox = QVBoxLayout(self.scroll_content)
        self.cards_vbox.setContentsMargins(0, 0, 0, 0)
        self.cards_vbox.setSpacing(4)
        self.cards_vbox.addStretch()

        self.scroll_area.setWidget(self.scroll_content)
        native_layout.addWidget(self.scroll_area)

        native_bottom = QHBoxLayout()

        self.btn_select_all = QPushButton("Tümünü Seç / Bırak")
        self.btn_select_all.setObjectName("SecondaryButton")
        self.btn_select_all.clicked.connect(self.toggle_select_all)

        self.btn_commit_native = QPushButton("Güncellemeyi Başlat")
        self.btn_commit_native.setObjectName("CommitButton")
        self.btn_commit_native.clicked.connect(self.prompt_transaction_review)

        native_bottom.addWidget(self.btn_select_all)
        native_bottom.addStretch()
        native_bottom.addWidget(self.btn_commit_native)

        native_layout.addLayout(native_bottom)
        self.pages_stack.addWidget(page_native)

        # PAGE 2: AYAS OS PAKETLERİ
        page_ayas = QWidget()
        ayas_layout = QVBoxLayout(page_ayas)
        ayas_layout.setContentsMargins(8, 8, 8, 8)

        self.search_bar_ayas = QLineEdit()
        self.search_bar_ayas.setObjectName("SearchBar")
        self.search_bar_ayas.setPlaceholderText("🔍 Ayas OS paketi ara...")
        self.search_bar_ayas.textChanged.connect(self.on_search_text_changed)
        ayas_layout.addWidget(self.search_bar_ayas)
        
        self.scroll_area_ayas = QScrollArea()
        self.scroll_area_ayas.setWidgetResizable(True)
        self.scroll_area_ayas.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        self.scroll_content_ayas = QWidget()
        self.cards_vbox_ayas = QVBoxLayout(self.scroll_content_ayas)
        self.cards_vbox_ayas.setContentsMargins(0, 0, 0, 0)
        self.cards_vbox_ayas.setSpacing(4)
        self.cards_vbox_ayas.addStretch()
        
        self.scroll_area_ayas.setWidget(self.scroll_content_ayas)
        ayas_layout.addWidget(self.scroll_area_ayas)

        ayas_bottom = QHBoxLayout()
        self.btn_select_all_ayas = QPushButton("Tümünü Seç / Bırak")
        self.btn_select_all_ayas.setObjectName("SecondaryButton")
        self.btn_select_all_ayas.clicked.connect(self.toggle_select_all)

        btn_commit_ayas = QPushButton("Güncellemeyi Başlat")
        btn_commit_ayas.setObjectName("CommitButton")
        btn_commit_ayas.clicked.connect(self.prompt_transaction_review)

        ayas_bottom.addWidget(self.btn_select_all_ayas)
        ayas_bottom.addStretch()
        ayas_bottom.addWidget(btn_commit_ayas)
        ayas_layout.addLayout(ayas_bottom)

        self.pages_stack.addWidget(page_ayas)

        # PAGE 3: FLATPAK PAKETLERİ
        page_fp = QWidget()
        fp_layout = QVBoxLayout(page_fp)
        fp_layout.setContentsMargins(8, 8, 8, 8)

        self.search_bar_fp = QLineEdit()
        self.search_bar_fp.setObjectName("SearchBar")
        self.search_bar_fp.setPlaceholderText("🔍 Flatpak uygulaması ara...")
        self.search_bar_fp.textChanged.connect(self.on_search_text_changed)
        fp_layout.addWidget(self.search_bar_fp)
        
        self.scroll_area_fp = QScrollArea()
        self.scroll_area_fp.setWidgetResizable(True)
        self.scroll_area_fp.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        self.scroll_content_fp = QWidget()
        self.cards_vbox_fp = QVBoxLayout(self.scroll_content_fp)
        self.cards_vbox_fp.setContentsMargins(0, 0, 0, 0)
        self.cards_vbox_fp.setSpacing(4)
        self.cards_vbox_fp.addStretch()
        
        self.scroll_area_fp.setWidget(self.scroll_content_fp)
        fp_layout.addWidget(self.scroll_area_fp)

        fp_bottom = QHBoxLayout()
        self.btn_select_all_fp = QPushButton("Tümünü Seç / Bırak")
        self.btn_select_all_fp.setObjectName("SecondaryButton")
        self.btn_select_all_fp.clicked.connect(self.toggle_select_all)

        btn_commit_fp = QPushButton("Güncellemeyi Başlat")
        btn_commit_fp.setObjectName("CommitButton")
        btn_commit_fp.clicked.connect(self.prompt_transaction_review)

        fp_bottom.addWidget(self.btn_select_all_fp)
        fp_bottom.addStretch()
        fp_bottom.addWidget(btn_commit_fp)
        fp_layout.addLayout(fp_bottom)

        self.pages_stack.addWidget(page_fp)

        # PAGE 4: DEPO & APT AYARLARI
        page_settings = QWidget()
        set_layout = QVBoxLayout(page_settings)
        set_layout.setContentsMargins(14, 14, 14, 14)
        set_layout.setSpacing(12)

        set_layout.addWidget(QLabel("<b style='color: #ffffff;'>Sistem Depo Aynası (Mirror)</b>"))
        set_layout.addWidget(QLabel("<span style='color: #a0a0b0; font-size: 11px;'>Ayas OS Temel Paket Depo Kaynağı</span>"))

        mirror_box = QHBoxLayout()
        self.mirror_input = QLineEdit("https://AYASCELL.github.io/ayasos-repo/")
        self.mirror_input.setObjectName("SearchBar")
        self.mirror_input.setReadOnly(True)
        self.mirror_input.setStyleSheet("color: #a0a0b0; background-color: #24242c; border: 1px solid #30303b;")
        mirror_check = QLabel("✓ Sistem Yönetiminde")
        mirror_check.setStyleSheet("color: #3fb950; font-weight: bold; font-size: 11px;")
        mirror_box.addWidget(self.mirror_input)
        mirror_box.addWidget(mirror_check)
        set_layout.addLayout(mirror_box)

        set_layout.addSpacing(10)
        set_layout.addWidget(QLabel("<b style='color: #ffffff;'>İlave & Özel APT Depoları (Sistem Tarafından Yönetilir)</b>"))

        self.repo_table = QTableWidget(0, 2)
        self.repo_table.setHorizontalHeaderLabels(["APT Deposu", "Durum"])
        self.repo_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.repo_table.setStyleSheet("QTableWidget { background-color: #24242c; color: #a0a0b0; border: 1px solid #30303b; gridline-color: #30303b; }")
        self.repo_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.repo_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)

        self.load_apt_repos()
        set_layout.addWidget(self.repo_table)

        apt_repo_bar = QHBoxLayout()
        btn_open_apt_folder = QPushButton("📂 Depo Klasörünü Aç (/etc/apt/sources.list.d/)")
        btn_open_apt_folder.setObjectName("SecondaryButton")
        btn_open_apt_folder.clicked.connect(self.on_open_apt_folder)

        btn_refresh_apt = QPushButton("🔄 APT Depolarını Yenile")
        btn_refresh_apt.setObjectName("SecondaryButton")
        btn_refresh_apt.clicked.connect(self.on_refresh_apt_repos)

        apt_repo_bar.addWidget(btn_open_apt_folder)
        apt_repo_bar.addWidget(btn_refresh_apt)
        apt_repo_bar.addStretch()
        set_layout.addLayout(apt_repo_bar)

        self.pages_stack.addWidget(page_settings)

        # PAGE 5: FLATPAK AYARLARI
        page_fp_settings = QWidget()
        fp_set_layout = QVBoxLayout(page_fp_settings)
        fp_set_layout.setContentsMargins(14, 14, 14, 14)
        fp_set_layout.setSpacing(12)

        fp_set_layout.addWidget(QLabel("<b style='color: #ffffff;'>Kurulu Flatpak Depoları (Remotes)</b>"))

        self.fp_repo_table = QTableWidget(0, 2)
        self.fp_repo_table.setHorizontalHeaderLabels(["Remote Adı", "Hedef (User/System)"])
        self.fp_repo_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.fp_repo_table.setStyleSheet("QTableWidget { background-color: #24242c; color: #f0f0f5; border: 1px solid #30303b; gridline-color: #30303b; }")

        self.load_flatpak_remotes()
        fp_set_layout.addWidget(self.fp_repo_table)

        fp_repo_bar = QHBoxLayout()
        btn_open_fp = QPushButton("📂 Flatpak Klasörünü Aç")
        btn_open_fp.setObjectName("SecondaryButton")
        btn_open_fp.clicked.connect(self.on_open_flatpak_folder)

        btn_refresh_fp = QPushButton("🔄 Depoları Yenile")
        btn_refresh_fp.setObjectName("SecondaryButton")
        btn_refresh_fp.clicked.connect(self.on_refresh_flatpak_remotes)

        fp_repo_bar.addWidget(btn_open_fp)
        fp_repo_bar.addWidget(btn_refresh_fp)
        fp_repo_bar.addStretch()
        
        fp_set_layout.addLayout(fp_repo_bar)
        
        self.pages_stack.addWidget(page_fp_settings)

        # PAGE 6: TERMINAL LOGLARI
        page_logs = QWidget()
        log_layout = QVBoxLayout(page_logs)
        log_layout.setContentsMargins(10, 10, 10, 10)
        log_layout.setSpacing(8)

        log_top_bar = QHBoxLayout()
        btn_live_logs = QPushButton("🟢 Canlı İşlem Logları")
        btn_live_logs.setObjectName("SecondaryButton")
        btn_live_logs.clicked.connect(self.on_show_live_logs)

        btn_hist_logs = QPushButton("📜 Geçmiş Güncellemeler (Son 7 Gün)")
        btn_hist_logs.setObjectName("SecondaryButton")
        btn_hist_logs.clicked.connect(self.on_show_history_logs)

        btn_clear_logs = QPushButton("🧹 Geçmişi Temizle")
        btn_clear_logs.setObjectName("SecondaryButton")
        btn_clear_logs.clicked.connect(self.on_clear_history_logs)

        log_top_bar.addWidget(btn_live_logs)
        log_top_bar.addWidget(btn_hist_logs)
        log_top_bar.addStretch()
        log_top_bar.addWidget(btn_clear_logs)

        log_layout.addLayout(log_top_bar)

        self.log_view = QTextEdit()
        self.log_view.setObjectName("LogView")
        self.log_view.setReadOnly(True)
        log_layout.addWidget(self.log_view)

        self.live_log_buffer = []

        self.pages_stack.addWidget(page_logs)

        right_layout.addWidget(self.pages_stack)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        right_layout.addWidget(self.progress_bar)

        root_layout.addWidget(right_container)

    def init_tray(self):
        from PyQt6.QtWidgets import QStyle
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon))
        self.tray_icon.setToolTip("Ayas OS Güncelleme Yöneticisi")
        
        tray_menu = QMenu(self)
        action_show = QAction("Ayas OS Güncelleyiciyi Aç", self)
        action_show.triggered.connect(self.show)

        action_check = QAction("Güncellemeleri Denetle", self)
        action_check.triggered.connect(self.on_check_updates)

        action_quit = QAction("Çıkış", self)
        action_quit.triggered.connect(sys.exit)

        tray_menu.addAction(action_show)
        tray_menu.addAction(action_check)
        tray_menu.addSeparator()
        tray_menu.addAction(action_quit)

        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.show()

    def check_internet_connection(self):
        try:
            urllib.request.urlopen("http://connectivitycheck.gstatic.com/generate_204", timeout=3)
            self.net_banner.setVisible(False)
        except Exception:
            self.net_banner.setVisible(True)

    def load_apt_repos(self):
        import glob
        import os
        
        self.repo_table.setRowCount(0)
        
        sources = []
        if os.path.exists("/etc/apt/sources.list"):
            sources.append("/etc/apt/sources.list")
            
        for f in glob.glob("/etc/apt/sources.list.d/*.list"):
            sources.append(f)
            
        for f in sources:
            try:
                with open(f, 'r', encoding='utf-8') as file:
                    for line in file:
                        clean_line = line.strip()
                        if not clean_line or clean_line.startswith("#") and "deb " not in clean_line:
                            continue
                            
                        # Aktif veya Devre dışı tespiti
                        enabled = "Aktif"
                        repo_line = clean_line
                        
                        if clean_line.startswith("#"):
                            enabled = "Devre Dışı"
                            repo_line = clean_line.lstrip("#").strip()
                            
                        if repo_line.startswith("deb ") or repo_line.startswith("deb-src "):
                            row = self.repo_table.rowCount()
                            self.repo_table.insertRow(row)
                            item_name = QTableWidgetItem(f"{os.path.basename(f)}: {repo_line}")
                            item_name.setData(Qt.ItemDataRole.UserRole, f)
                            self.repo_table.setItem(row, 0, item_name)
                            self.repo_table.setItem(row, 1, QTableWidgetItem(enabled))
            except Exception:
                pass

    def on_open_apt_folder(self):
        import os
        folder_path = "/etc/apt/sources.list.d"
        if not os.path.exists(folder_path):
            folder_path = "/etc/apt"
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder_path))

    def on_refresh_apt_repos(self):
        try:
            res = subprocess.run(["pkexec", "apt-get", "update"], capture_output=True, text=True, check=False)
            if res.returncode == 0:
                self.load_apt_repos()
                QMessageBox.information(self, "Başarılı", "APT depo paket listeleri başarıyla güncellendi.")
            else:
                QMessageBox.warning(self, "Hata", f"APT depoları güncellenirken bir hata oluştu:\n{res.stderr}")
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"İşlem sırasında hata oluştu: {str(e)}")

    def on_open_update_settings(self):
        dialog = UpdateSettingsDialog(self)
        dialog.exec()

    def on_open_flatpak_folder(self):
        import os
        folder_path = "/var/lib/flatpak/repo"
        if not os.path.exists(folder_path):
            folder_path = "/var/lib/flatpak"
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder_path))

    def load_flatpak_remotes(self):
        self.fp_repo_table.setRowCount(0)
        try:
            res = subprocess.run(
                ["flatpak", "remotes", "--columns=name,url,options"],
                capture_output=True, text=True, check=False
            )
            if res.returncode == 0 and res.stdout.strip():
                lines = res.stdout.strip().split("\n")
                for line in lines:
                    parts = [p.strip() for p in line.split("\t")]
                    if len(parts) >= 2:
                        name = parts[0]
                        url = parts[1]
                        options = parts[2] if len(parts) > 2 else ""
                        
                        target = "System" if "system" in options.lower() else "User"
                        
                        row = self.fp_repo_table.rowCount()
                        self.fp_repo_table.insertRow(row)
                        item_name = QTableWidgetItem(f"{name} ({url})")
                        item_name.setData(Qt.ItemDataRole.UserRole, (name, url, target))
                        self.fp_repo_table.setItem(row, 0, item_name)
                        self.fp_repo_table.setItem(row, 1, QTableWidgetItem(target))
        except Exception:
            pass

    def on_refresh_flatpak_remotes(self):
        try:
            self.load_flatpak_remotes()
            QMessageBox.information(self, "Başarılı", "Flatpak depo listesi başarıyla yenilendi.")
        except Exception as e:
            QMessageBox.warning(self, "Hata", f"Flatpak depoları yenilenirken hata oluştu: {str(e)}")

    def on_show_about(self):
        dialog = AboutDialog(self)
        dialog.exec()

    def update_auto_check_timer(self):
        settings = load_settings()
        if settings.get("auto_check", True):
            hours = settings.get("check_interval_hours", 6)
            interval_ms = max(1, hours) * 3600 * 1000
            self.auto_check_timer.start(interval_ms)
        else:
            self.auto_check_timer.stop()

    def on_auto_check_timer_timeout(self):
        settings = load_settings()
        if settings.get("auto_check", True):
            self.on_check_updates()

    # ==========================================
    # İŞ MANTIĞI & SAYFA GEÇİŞLERİ
    # ==========================================
    def on_sidebar_changed(self, row):
        if row == 7:
            self.sidebar_list.blockSignals(True)
            self.sidebar_list.setCurrentRow(self.current_sidebar_row)
            self.sidebar_list.blockSignals(False)
            self.on_open_update_settings()
        else:
            self.current_sidebar_row = row
            self.pages_stack.setCurrentIndex(row)

    def show_loading_state(self):
        def clear_layout(layout):
            while layout.count() > 1:
                item = layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.setParent(None)
                    widget.deleteLater()

        clear_layout(self.cards_vbox)
        clear_layout(self.cards_vbox_fp)
        clear_layout(self.cards_vbox_ayas)

        for card in self.cards_list:
            card.setParent(None)
            card.deleteLater()
        self.cards_list.clear()
        self.all_card_widgets.clear()

        def add_loading_label(layout, msg):
            lbl = QLabel(msg)
            lbl.setStyleSheet("color: #58a6ff; font-weight: bold; font-size: 13px; padding: 20px;")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.insertWidget(0, lbl)

        add_loading_label(self.cards_vbox, "⏳ Sistem paketleri (APT) denetleniyor...")
        add_loading_label(self.cards_vbox_fp, "⏳ Flatpak uygulamaları denetleniyor...")
        add_loading_label(self.cards_vbox_ayas, "⏳ Ayas OS paketleri denetleniyor...")

    def on_check_updates(self):
        if getattr(self, 'check_thread', None) and self.check_thread.isRunning():
            return
            
        self.dash_title.setText("Güncellemeler Kontrol Ediliyor...")
        self.dash_icon_label.setText("🔍")
        self.show_loading_state()
        self.check_thread = CheckUpdatesThread()
        self.check_thread.log_line.connect(self.on_log_line)
        self.check_thread.updates_found.connect(self.on_updates_found)
        self.check_thread.error_occurred.connect(self.on_check_error)
        self.check_thread.start()

    def on_updates_found(self, packages):
        self.current_packages = packages
        total_c = len(packages)
        ayas_c = sum(1 for p in packages if p.get('is_ayasos'))
        fp_c = sum(1 for p in packages if p.get('is_flatpak'))
        apt_c = total_c - ayas_c - fp_c

        self.val_total.setText(str(total_c))
        self.val_apt.setText(str(apt_c))
        self.val_ayas.setText(str(ayas_c))
        self.val_fp.setText(str(fp_c))

        if total_c == 0:
            self.dash_title.setText("Sisteminiz Güncel!")
            self.dash_icon_label.setText("✅")
        else:
            self.dash_title.setText("Güncellemeler Mevcut!")
            self.dash_icon_label.setText("📦")

            try:
                self.tray_icon.showMessage(
                    "Ayas OS Güncelleme Yöneticisi",
                    f"Sisteminizde {total_c} yeni güncelleme tespit edildi!",
                    QSystemTrayIcon.MessageIcon.Information,
                    5000
                )
            except Exception:
                pass

        self.render_package_cards()

    def render_package_cards(self):
        # Önceki tüm kartları temizle
        def clear_layout(layout):
            while layout.count() > 1: # Son eleman addStretch olduğu için 1 bırakılır
                item = layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.setParent(None)
                    widget.deleteLater()

        clear_layout(self.cards_vbox)
        clear_layout(self.cards_vbox_fp)
        clear_layout(self.cards_vbox_ayas)

        for card in self.cards_list:
            card.setParent(None)
            card.deleteLater()
        self.cards_list.clear()
        
        # We don't delete elements from all_card_widgets here because they are
        # already deleted when the layouts are cleared above (via clear_layout).
        self.all_card_widgets.clear()

        filter_text = self.search_bar.text().lower()
        
        has_native = False
        has_fp = False
        has_ayas = False

        for pkg in self.current_packages:
            if filter_text and filter_text not in pkg['name'].lower():
                continue

            card_widget = PackageCardWidget(pkg)
            self.cards_list.append(card_widget)
            self.all_card_widgets.append(card_widget)
            
            if pkg.get('is_flatpak'):
                card_widget_fp = PackageCardWidget(pkg)
                self.all_card_widgets.append(card_widget_fp)
                self.cards_vbox_fp.insertWidget(self.cards_vbox_fp.count() - 1, card_widget_fp)
                has_fp = True
            else:
                self.cards_vbox.insertWidget(self.cards_vbox.count() - 1, card_widget)
                has_native = True
                if pkg.get('is_ayasos'):
                    card_widget_ayas = PackageCardWidget(pkg)
                    self.all_card_widgets.append(card_widget_ayas)
                    self.cards_vbox_ayas.insertWidget(self.cards_vbox_ayas.count() - 1, card_widget_ayas)
                    has_ayas = True

        def add_empty_label(layout, msg):
            lbl = QLabel(msg)
            lbl.setStyleSheet("color: #a0a0b0; font-style: italic;")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.insertWidget(0, lbl)

        if not has_native:
            add_empty_label(self.cards_vbox, "Kurulmayı bekleyen sistem (APT) paketi yok.")
        if not has_fp:
            add_empty_label(self.cards_vbox_fp, "Flatpak uygulamalarınız tamamen güncel.")
        if not has_ayas:
            add_empty_label(self.cards_vbox_ayas, "Ayas OS özel paketleriniz tamamen güncel.")

    def on_search_text_changed(self, text):
        for sb in [getattr(self, 'search_bar', None), getattr(self, 'search_bar_ayas', None), getattr(self, 'search_bar_fp', None)]:
            if sb and sb.text() != text:
                sb.blockSignals(True)
                sb.setText(text)
                sb.blockSignals(False)
        self.render_package_cards()

    def filter_packages(self):
        self.render_package_cards()

    def toggle_select_all(self):
        all_checked = any(c.checkbox.isChecked() for c in self.all_card_widgets)
        new_state = not all_checked
        for card in self.all_card_widgets:
            card.checkbox.setChecked(new_state)
        btn_text = "Tümünü Seç" if not new_state else "Tümünü Bırak"
        if hasattr(self, 'btn_select_all'):
            self.btn_select_all.setText(btn_text)
        if hasattr(self, 'btn_select_all_ayas'):
            self.btn_select_all_ayas.setText(btn_text)
        if hasattr(self, 'btn_select_all_fp'):
            self.btn_select_all_fp.setText(btn_text)

    def on_add_repo(self):
        dialog = AddRepoDialog(parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            data = dialog.get_data()
            row = self.repo_table.rowCount()
            self.repo_table.insertRow(row)
            self.repo_table.setItem(row, 0, QTableWidgetItem(f"{data['uri']} {data['suite']} {data['comp']}"))
            self.repo_table.setItem(row, 1, QTableWidgetItem("Aktif"))

    def on_edit_repo(self):
        curr_row = self.repo_table.currentRow()
        if curr_row < 0:
            QMessageBox.warning(self, "Uyarı", "Lütfen düzenlemek için bir depo satırı seçin.")
            return

        curr_url = self.repo_table.item(curr_row, 0).text()
        dialog = AddRepoDialog({"uri": curr_url}, parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            data = dialog.get_data()
            self.repo_table.setItem(curr_row, 0, QTableWidgetItem(f"{data['uri']} {data['suite']} {data['comp']}"))

    def on_delete_repo(self):
        curr_row = self.repo_table.currentRow()
        if curr_row >= 0:
            self.repo_table.removeRow(curr_row)

    def prompt_transaction_review(self):
        selected_pkgs = []
        unselected_apt = []
        for p in self.current_packages:
            if p.get('selected', True):
                selected_pkgs.append(p)
            elif not p.get('is_flatpak'):
                unselected_apt.append(p['name'])

        total_c = len(selected_pkgs)
        if total_c == 0:
            QMessageBox.information(self, "Bilgi", "Uygulanacak bir güncelleme seçilmedi.")
            return

        fp_c = sum(1 for p in selected_pkgs if p.get('is_flatpak'))
        apt_c = total_c - fp_c
        
        stats = {
            "upgrade": apt_c,
            "install": 1 if any(p.get('is_ayasos') for p in selected_pkgs) else 0,
            "flatpak": fp_c,
            "uninstall": 0,
            "download_size": f"~{max(total_c * 2, 1.5):.1f} MB",
            "disk_size": f"~{max(total_c * 5, 4.2):.1f} MB"
        }

        dialog = TransactionReviewDialog(stats, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.on_perform_update(selected_pkgs, unselected_apt)

    def on_check_error(self, err):
        self.dash_title.setText("Güncelleme Hatası")
        self.log_view.append(f"[HATA] {err}")

    def on_perform_update(self, selected_pkgs, unselected_apt):
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.sidebar_list.setCurrentRow(6) # Terminal Logları
        self.live_log_buffer.clear()
        self.log_view.clear()

        self.update_thread = PerformUpdateThread(selected_pkgs, unselected_apt)
        self.update_thread.progress_changed.connect(self.on_update_progress)
        self.update_thread.log_line.connect(self.on_log_line)
        self.update_thread.update_finished.connect(self.on_update_finished)
        self.update_thread.reboot_required_signal.connect(self.on_reboot_required)
        self.update_thread.start()

    def on_update_progress(self, val, msg):
        self.progress_bar.setValue(val)

    def on_log_line(self, line):
        self.live_log_buffer.append(line)
        self.log_view.append(line)
        sb = self.log_view.verticalScrollBar()
        sb.setValue(sb.maximum())

    def on_show_live_logs(self):
        self.log_view.clear()
        if self.live_log_buffer:
            self.log_view.setText("\n".join(self.live_log_buffer))
        else:
            self.log_view.setText("[AYAS OS] Henüz aktif bir güncelleme işlemi başlatılmadı.")
        sb = self.log_view.verticalScrollBar()
        sb.setValue(sb.maximum())

    def on_show_history_logs(self):
        import os
        from engine import get_history_log_path, clean_old_history_logs
        clean_old_history_logs(7)
        log_path = get_history_log_path()

        self.log_view.clear()
        if os.path.exists(log_path):
            try:
                with open(log_path, "r", encoding="utf-8") as f:
                    content = f.read()
                if content.strip():
                    self.log_view.setText(content)
                else:
                    self.log_view.setText("[AYAS OS] Son 7 güne ait kaydedilmiş geçmiş log bulunamadı.")
            except Exception as e:
                self.log_view.setText(f"[HATA] Geçmiş loglar okunurken hata oluştu: {str(e)}")
        else:
            self.log_view.setText("[AYAS OS] Son 7 güne ait henüz kaydedilmiş geçmiş log bulunamadı.")

        sb = self.log_view.verticalScrollBar()
        sb.setValue(sb.maximum())

    def on_clear_history_logs(self):
        import os
        from engine import get_history_log_path
        log_path = get_history_log_path()
        if os.path.exists(log_path):
            try:
                os.remove(log_path)
                self.log_view.setText("[AYAS OS] Geçmiş log kaydı başarıyla temizlendi.")
                QMessageBox.information(self, "Başarılı", "Geçmiş güncelleme logları temizlendi.")
            except Exception as e:
                QMessageBox.warning(self, "Hata", f"Loglar temizlenirken hata oluştu: {str(e)}")
        else:
            QMessageBox.information(self, "Bilgi", "Temizlenecek geçmiş log bulunmuyor.")

    def on_reboot_required(self, is_req):
        if is_req:
            self.reboot_banner.setVisible(True)

    def on_reboot_now(self):
        try:
            subprocess.run(["systemctl", "reboot"], check=False)
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Yeniden başlatma komutu çalıştırılamadı: {str(e)}")

    def on_update_finished(self, success, msg):
        self.progress_bar.setVisible(False)
        if success:
            QMessageBox.information(self, "Başarılı", msg)
            self.on_check_updates()
        else:
            QMessageBox.critical(self, "Hata", msg)
