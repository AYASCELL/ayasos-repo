"""
Ayas OS Update Manager - APT & System Update Async Engine
"""

import sys
import subprocess
import re
import os
import datetime
from PyQt6.QtCore import QThread, pyqtSignal

try:
    import apt
    HAS_PYTHON_APT = True
except ImportError:
    HAS_PYTHON_APT = False


def get_history_log_path():
    state_dir = os.path.expanduser("~/.local/state/ayasos-updater")
    os.makedirs(state_dir, exist_ok=True)
    return os.path.join(state_dir, "history.log")


def append_to_history(msg):
    try:
        log_path = get_history_log_path()
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{now_str}] {msg}\n")
    except Exception:
        pass


def clean_old_history_logs(days=7):
    try:
        log_path = get_history_log_path()
        if not os.path.exists(log_path):
            return
        
        now = datetime.datetime.now()
        cutoff = now - datetime.timedelta(days=days)
        
        valid_lines = []
        with open(log_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("[") and "]" in line:
                    date_part = line[1:line.index("]")]
                    try:
                        line_date = datetime.datetime.strptime(date_part, "%Y-%m-%d %H:%M:%S")
                        if line_date >= cutoff:
                            valid_lines.append(line)
                    except ValueError:
                        valid_lines.append(line)
                else:
                    valid_lines.append(line)
                    
        with open(log_path, "w", encoding="utf-8") as f:
            f.writelines(valid_lines)
    except Exception:
        pass


class CheckUpdatesThread(QThread):
    """
    Sistemdeki ve Ayas OS deposundaki güncellemeleri kontrol eden arka plan thread'i.
    Canlı sunucudan (GitHub/Debian) en güncel paket verilerini çeker ve tarlar.
    """
    updates_found = pyqtSignal(list)
    log_line = pyqtSignal(str)
    error_occurred = pyqtSignal(str)

    def run(self):
        packages_list = []
        
        def print_log(msg):
            print(f"\033[1;36m[AYAS OS LOG]\033[0m {msg}", flush=True)
            self.log_line.emit(f"[AYAS OS] {msg}")

        print_log("Güncelleme denetleme işlemi başlatıldı...")

        try:
            print_log("GitHub ve Ayas OS depolarından en güncel paket verileri çekiliyor (apt-get update)...")
            res = subprocess.run(["pkexec", "apt-get", "update", "-q"], capture_output=True, text=True, check=False)
            if res.returncode == 0:
                print_log("Depo paket listeleri canlı olarak başarıyla güncellendi.")
            else:
                print_log("Bilgi: Canlı depo taraması atlandı veya izin verilmedi, yerel önbellek okunuyor.")

            if HAS_PYTHON_APT:
                print_log("python3-apt altyapısı ile paket veritabanı taranıyor...")
                cache = apt.Cache()
                cache.open(None)
                
                for pkg in cache:
                    if pkg.is_upgradable:
                        candidate = pkg.candidate
                        installed = pkg.installed
                        
                        # Size calculation
                        size_bytes = getattr(candidate, 'size', 0) or 0
                        if size_bytes >= 1048576:
                            size_str = f"~{size_bytes / 1048576:.1f} MB"
                        elif size_bytes >= 1024:
                            size_str = f"~{size_bytes / 1024:.1f} KB"
                        elif size_bytes > 0:
                            size_str = f"{size_bytes} Bytes"
                        else:
                            size_str = "Bilinmiyor"

                        # Maintainer calculation
                        maint = "Debian / Linux Topluluğu"
                        try:
                            if candidate.record and candidate.record.get('Maintainer'):
                                maint = candidate.record.get('Maintainer')
                        except Exception:
                            pass

                        # Site / Origin & Exact Download URI calculation
                        origin_site = ""
                        download_uri = ""
                        try:
                            if candidate.uris:
                                download_uri = candidate.uris[0].replace("/./", "/")
                            if candidate.origins:
                                for o in candidate.origins:
                                    if o.site:
                                        origin_site = o.site
                                        break
                                    elif o.origin:
                                        origin_site = o.origin
                                        break
                        except Exception:
                            pass

                        is_ayas = "ayas" in pkg.name.lower() or "ayascell" in pkg.name.lower()
                        if is_ayas:
                            origin_site = "https://AYASCELL.github.io/ayasos-repo/"
                        elif not origin_site:
                            origin_site = "Debian / Sistem Deposu"
                        elif not origin_site.startswith("http://") and not origin_site.startswith("https://"):
                            origin_site = f"https://{origin_site}"

                        packages_list.append({
                            "name": pkg.name,
                            "old_version": installed.version if installed else "Yüklü Değil",
                            "new_version": candidate.version,
                            "summary": candidate.summary or "Güncelleme mevcut",
                            "is_ayasos": is_ayas,
                            "maintainer": maint,
                            "size_str": size_str,
                            "origin_site": origin_site,
                            "download_uri": download_uri
                        })
            else:
                print_log("apt CLI altyapısı ile güncellenebilir paketler taranıyor...")
                res = subprocess.run(["apt", "list", "--upgradable"], capture_output=True, text=True, check=False)
                
                lines = res.stdout.strip().split("\n")
                for line in lines:
                    if "/" in line and "[" in line:
                        parts = line.split()
                        pkg_name = parts[0].split("/")[0]
                        new_ver = parts[1]
                        old_ver = "Bilinmiyor"
                        if "from:" in line:
                            old_ver = line.split("from:")[1].replace("]", "").strip()
                        
                        is_ayas = "ayas" in pkg_name.lower() or "ayascell" in pkg_name.lower()
                        maint = "AYAS OS Ekibi <info@ayasos.org>" if is_ayas else "Debian / Linux Topluluğu"
                        site = "https://AYASCELL.github.io/ayasos-repo/" if is_ayas else "Debian / Sistem Deposu"

                        packages_list.append({
                            "name": pkg_name,
                            "old_version": old_ver,
                            "new_version": new_ver,
                            "summary": f"{pkg_name} yeni sürüm: {new_ver}",
                            "is_ayasos": is_ayas,
                            "maintainer": maint,
                            "size_str": "~1.2 MB",
                            "origin_site": site
                        })

            packages_list.sort(key=lambda x: (not x["is_ayasos"], x["name"]))

            # --- FLATPAK GÜNCELLEMELERİNİ DENETLE ---
            print_log("Flatpak güncellemeleri taranıyor...")
            try:
                res_fp = subprocess.run(
                    ["flatpak", "remote-ls", "--updates", "--columns=application,name,version,branch,arch,origin,size"],
                    capture_output=True, text=True, check=False
                )
                if res_fp.returncode == 0 and res_fp.stdout.strip():
                    fp_lines = res_fp.stdout.strip().split("\n")
                    for line in fp_lines:
                        parts = [p.strip() for p in line.split("\t")]
                        if len(parts) >= 6:
                            app_id, name, version, branch, arch, origin = parts[:6]
                            size = parts[6] if len(parts) > 6 else "~"
                            packages_list.append({
                                "name": name or app_id,
                                "old_version": "Mevcut",
                                "new_version": version or branch,
                                "summary": f"({origin} - {arch}) {app_id}\nTahmini İndirme Boyutu: {size}",
                                "is_ayasos": False,
                                "is_flatpak": True,
                                "flatpak_id": app_id
                            })
            except Exception as e:
                print_log(f"Flatpak taraması atlandı: {str(e)}")
            # ----------------------------------------

            print_log(f"Tarama tamamlandı! Toplam {len(packages_list)} adet güncellenebilir paket bulundu.")
            
            for p in packages_list:
                if p.get("is_flatpak"):
                    tag = "[FLATPAK UYGULAMASI]"
                else:
                    tag = "[AYAS OS PAKETİ]" if p["is_ayasos"] else "[SİSTEM]"
                print_log(f" -> {tag} {p['name']} ({p['old_version']} ➔ {p['new_version']})")

            self.updates_found.emit(packages_list)

        except Exception as e:
            err_str = f"Hata oluştu: {str(e)}"
            print_log(f"\033[1;31m{err_str}\033[0m")
            self.error_occurred.emit(err_str)


class PerformUpdateThread(QThread):
    """
    Polkit (pkexec) kullanarak güncellemeleri güvenle canlı uygulayan thread.
    Hem terminale hem GUI'ye canlı log aktarır.
    """
    progress_changed = pyqtSignal(int, str)
    log_line = pyqtSignal(str)
    update_finished = pyqtSignal(bool, str)
    reboot_required_signal = pyqtSignal(bool)

    def __init__(self, selected_pkgs=None, unselected_apt=None):
        super().__init__()
        self.selected_pkgs = selected_pkgs if selected_pkgs is not None else []
        self.unselected_apt = unselected_apt if unselected_apt is not None else []

    def run(self):
        selected_apt = [p['name'] for p in self.selected_pkgs if not p.get('is_flatpak')]

        if self.unselected_apt and selected_apt:
            # Sadece seçilen paketleri güvenle güncelle
            cmd = [
                "pkexec", "env", "DEBIAN_FRONTEND=noninteractive",
                "apt-get", "install", "--only-upgrade", "-y",
                "-o", "Dpkg::Options::=--force-confdef",
                "-o", "Dpkg::Options::=--force-confold"
            ] + selected_apt
        elif not selected_apt:
            # Seçili APT paketi yok, APT adımını atla
            cmd = None
        else:
            # Tüm paketler seçili, tam dist-upgrade yap
            cmd = [
                "pkexec", "env", "DEBIAN_FRONTEND=noninteractive",
                "apt-get", "dist-upgrade", "-y",
                "-o", "Dpkg::Options::=--force-confdef",
                "-o", "Dpkg::Options::=--force-confold"
            ]

        clean_old_history_logs(7)

        def print_log(msg):
            print(f"\033[1;32m[AYAS OS UPDATE]\033[0m {msg}", flush=True)
            self.log_line.emit(msg)
            append_to_history(msg)

        print_log("[AYAS OS] Güncelleme işlemi başlatılıyor...")
        self.progress_changed.emit(5, "Kurulum yetkileri doğrulanıyor...")

        try:
            return_code = 0
            if cmd is not None:
                process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1
                )

                progress = 10
                for line in iter(process.stdout.readline, ''):
                    if not line:
                        break
                    clean_line = line.strip()
                    print_log(clean_line)

                    if "Get:" in clean_line:
                        progress = min(progress + 3, 50)
                        self.progress_changed.emit(progress, "Paketler indiriliyor...")
                    elif "Unpacking" in clean_line or "Preparing to unpack" in clean_line:
                        progress = min(progress + 2, 75)
                        self.progress_changed.emit(progress, "Paketler çıkarılıyor...")
                    elif "Setting up" in clean_line or "Configuring" in clean_line:
                        progress = min(progress + 2, 95)
                        self.progress_changed.emit(progress, "Sistem yapılandırılıyor...")

                process.stdout.close()
                return_code = process.wait()

            if return_code == 0:
                # Check for reboot required
                import os
                if os.path.exists("/var/run/reboot-required"):
                    self.reboot_required_signal.emit(True)

                selected_fp = [p['name'] for p in self.selected_pkgs if p.get('is_flatpak')]
                
                if selected_fp:
                    print_log("[FLATPAK] Seçili Flatpak uygulamaları güncelleniyor...")
                    self.progress_changed.emit(90, "Flatpak uygulamaları güncelleniyor...")
                    
                    fp_cmd = ["flatpak", "update", "-y"] + selected_fp
                    fp_process = subprocess.Popen(
                        fp_cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        bufsize=1
                    )
                    
                    for line in iter(fp_process.stdout.readline, ''):
                        if not line:
                            break
                        print_log("[FLATPAK] " + line.strip())
                    
                    fp_process.stdout.close()
                    fp_return_code = fp_process.wait()
                    
                    if fp_return_code == 0:
                        self.progress_changed.emit(100, "Güncelleme Başarıyla Tamamlandı!")
                        self.update_finished.emit(True, "Seçili paketler ve uygulamalar başarıyla güncellendi!")
                    else:
                        err = "Flatpak güncellemesi sırasında hata oluştu."
                        print_log(f"\033[1;31m[HATA]\033[0m {err}")
                        self.update_finished.emit(False, err)
                else:
                    self.progress_changed.emit(100, "Güncelleme Başarıyla Tamamlandı!")
                    self.update_finished.emit(True, "Seçili paketler başarıyla güncellendi!")
            else:
                self.update_finished.emit(False, f"Sistem güncellemesi hatayla sonlandı (Kod: {return_code}).")
        except Exception as e:
            self.update_finished.emit(False, f"Hata oluştu: {str(e)}")


DEFAULT_SETTINGS = {
    "auto_check": True,
    "check_interval_hours": 6,
    "show_notifications": True,
    "autostart_on_boot": True
}

def get_settings_path():
    import os
    config_dir = os.path.expanduser("~/.config/ayasos-updater")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "settings.json")

def load_settings():
    import os, json
    path = get_settings_path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                settings = DEFAULT_SETTINGS.copy()
                settings.update(data)
                return settings
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()

def save_settings(data):
    import json
    path = get_settings_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        return True
    except Exception:
        return False
