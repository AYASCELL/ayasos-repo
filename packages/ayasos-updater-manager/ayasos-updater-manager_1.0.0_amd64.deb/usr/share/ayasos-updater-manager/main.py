#!/usr/bin/env python3
"""
Ayas OS Güncelleme Yöneticisi (Ayas OS Update Manager)
Ana Başlatıcı Dosyası (Application Entry Point)
"""

import sys
import os
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon
from ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Ayas OS Güncelleme Yöneticisi")
    app.setOrganizationName("AYASCELL")

    # Pencereyi oluştur
    window = MainWindow()
    if "--tray" not in sys.argv and "--minimized" not in sys.argv:
        window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
